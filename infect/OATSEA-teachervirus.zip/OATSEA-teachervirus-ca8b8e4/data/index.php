<?php
// Default play home page
echo "Data Directory holds data that should be retained on a payload by payload basis.";
?>
