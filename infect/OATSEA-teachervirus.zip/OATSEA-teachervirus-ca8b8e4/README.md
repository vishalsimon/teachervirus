# Teacher Virus
Teacher Virus core files

See OATSEA/getinfected for php installation file that auto deploys this repository


