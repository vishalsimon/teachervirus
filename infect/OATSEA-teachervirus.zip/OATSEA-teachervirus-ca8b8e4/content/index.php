<?php
// Default play home page
echo "Content Directory holds payloads of a content nature.";
?>
