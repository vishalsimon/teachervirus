# tv-tiddlywiki
Example of Tiddlywiki as a payload for Teacher Virus
