# tv-twine
Example of a Twine payload for Teacher Virus

index.html is the "compiled" version of the twine file Teacher Virus Payload.html

You need the Twine programme to modify and create your own Twines - have a look at http://twinery.org/

Once you've created your own content simply add your creation to a github repository and let OATSEA know your username and repo name and we'll add it to the content directory for Teacher Virus and it will be available for infection.

Please make sure you rename your "published" Twine file "index.html" so that it loads by default.

Please also include the original twine file so that others see how you did it and mutate your work!
 
